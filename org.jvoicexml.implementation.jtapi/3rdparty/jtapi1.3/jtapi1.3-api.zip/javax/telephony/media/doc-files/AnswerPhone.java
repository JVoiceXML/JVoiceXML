/**
 * Example code from the ECTF working group.
 */

import java.util.*;

import javax.telephony.*;
import javax.telephony.media.*;

/**
 * Example answerPhone Java Telephony Media API usage
 * This example shows an application that implements 
 * an answering machine/message service.
 * <p>
 * The user interface is as follows: <br>
 * Each Address that the app runs on has a dedicated answering machine.
 * A caller is prompted to leave a message.
 * During the initial prompt the caller may enter <ul>
 * <li> a 4 digit password = "1234" : the caller enters playback mode</li>
 * <li> "*", or no input : a message is recorded.</li>
 * <li> "#" : request that answering machine hangup. </li>
 * <li> "0" : release call, with request for a live operator</li>
 * <li> other input causes the prompt to be replayed.</li>
 * </ul>
 * Note, a simple "operator" service can use Jtapi to transfer the call,
 * or play a message indicating no operator is available and disconnect.
 * <p>
 * During the Playback of messages, the following DTMF input is recognized:
 * <ul>
 * <li> "1" : stop playback, replay current message,</li>
 * <li> "2" : pause</li>
 * <li> "3" : resume</li>
 * <li> "4" : back up, replay a short segment</li>
 * <li> "6" : skip forward</li>
 * <li> "7" : slow down</li>
 * <li> "9" : speed up</li>
 * <li> "*" : stop playback, goto next message</li>
 * <li> "#" : stop playback, skip remaining messages, goto initial prompt</li>
 * </ul>
 * Other DTMF input is ignored during playback.
 * <p>
 * When recording, the message is recorded until terminated
 * by max duration (default), a DTMF, or hangup by caller. 
 * The message is inserted in the mailbox, 
 * and caller is returned to the initial prompt.
 * <p>
 * The app uses bindToServiceName() to be notified when a call comes in.
 * This method uses the MediaProvider's implementation that detects
 * an incoming call, selects the application name to be run,
 * and delivers the call to the application. 
 * <p>
 * One thread is created for each channel or port that
 * can be playing simultaneously. The AnswerPhone is started
 * on each thread and runs forever (doing a new bindToServiceName()
 * immediately after each call is completed.)  
 * <p>
 * A mailbox vector is assumed, which holds the messages for a mailbox.
 */

public class 
    AnswerPhone extends BasicMediaService implements Runnable {

    /* set up semantically meaningful local names for the Pattern Symbols*/
    static final Symbol stop   = SignalDetector.p_Pattern[1];
    static final Symbol drop   = SignalDetector.p_Pattern[2];
    static final Symbol replay = SignalDetector.p_Pattern[3];
    static final Symbol slow   = SignalDetector.p_Pattern[4];
    static final Symbol resume = SignalDetector.p_Pattern[5];
    static final Symbol fast   = SignalDetector.p_Pattern[6];
    static final Symbol back   = SignalDetector.p_Pattern[7];
    static final Symbol pause  = SignalDetector.p_Pattern[8];
    static final Symbol forw   = SignalDetector.p_Pattern[9];
    static final Symbol passwd = SignalDetector.p_Pattern[10];
    static final Symbol oper   = SignalDetector.p_Pattern[11];
    
    /**
     * define patterns for signal detector
     */
    static Hashtable patterns = new Hashtable();
    static {
	patterns.put(stop,   "*"); // stop prompt, goto record message
				   // stop playback, get next message
	patterns.put(drop,   "#"); // hangup
				   // stop playback, skip rest of messages
	patterns.put(replay, "1"); // stop playback, replay current message
	patterns.put(pause,  "2"); // RTC
	patterns.put(resume, "3"); // RTC
	patterns.put(back,   "4"); // RTC
	patterns.put(forw,   "6"); // RTC
	patterns.put(slow,   "7"); // RTC
	patterns.put(fast,   "9"); // RTC
	patterns.put(passwd, "{4}?"); // passwd implies get messages
	patterns.put(oper,   "0"); // release to "operator"
    }
    
    /**
     * An RTC array for playing the prompt.
     *  stop if a DTMF is detected.
     */
    static RTC[] promptRTC = { RTC.SigDet_StopPlay };
    
    /** get initial user service request */
    static Symbol[] DTMFRequest = { stop, drop, passwd };
    
    /**
     * An RTC array for controlling the playing of mailbox entries...
     */
    static RTC[] messageRTC = {new RTC(stop, Player.rtca_Stop),
			       new RTC(replay, Player.rtca_Stop),
			       new RTC(drop, Player.rtca_Stop),
			       new RTC(forw, Player.rtca_JumpForward),
			       new RTC(back, Player.rtca_JumpBackward),
			       new RTC(fast, Player.rtca_SpeedUp),
			       new RTC(slow, Player.rtca_SpeedDown),
			       new RTC(pause, Player.rtca_Pause),
			       new RTC(resume, Player.rtca_Resume)};
    
    /**
     *  initial prompt as an array of MSCs.
     */
    static String[] mainWelcome = {"Widgitek/Welcome",
				   "Widgitek/PleaseLeaveAMessage"};
    /**
     * tell user they botched the password
     */
    static String errMsg = "Widgitek/InvalidCode";

    static String msgSeparator = "Widgitek/Beep";

    /**
     * the users mail box.
     * a Vector of MSC Strings identifying the messages.
     */
    Vector mailBox = new Vector();
   
   /**
    * This method is invoked when AnswerPhone is run as an application
    * <p>
    * @usage java AnswerPhone
    */
   public static void main(String[] argv) throws Exception {
       /* Kick off 5 threads to provide the service...
	* Each service is an instance of AnswerPhone.
	* AnswerPhone implements the Runnable interface and 
	* the <code>run()</code> method is invoked when
	* the thread is started.
	*/
       for (int i = 0; i < 5; i++) {
	   // assume default Provider of default Peer is a MediaProvider
	   new Thread(new AnswerPhone()).start();
       }
   }

    /** 
     * The real work starts here...
     * This method is called when the thread is started.
     */
    public void run() {
	while (true)		// this is NOT a RunnableMediaService
	    try {
		bindToServiceName(ConfigSpec.basicConfig, "AnswerPhone");
		userRequest("1234"); // userRequest will release()
	    } catch (Exception ex) {
		System.err.println(ex);
	    }
    }
    
    /* various events used in userRequest */
    SignalDetector.Event sdev;
    Recorder.Event rev;
    Player.Event pev;
    Symbol qual;
    Symbol rtcc;

    /**
     * Run the toplevel user-interaction loop, then release.
     */
    void userRequest(String password) {
	setParameters(patterns);
	try {
	    while (true) {
		// play the welcome...
		pev = play(mainWelcome, 0, promptRTC, null);
		// stop when DTMF or play done.
		
		if(pev.getQualifier() != pev.q_EndOfData)
		    // retrieve a DTMF (assumes reasonable timeout defaults)
		    sdev = retrieveSignals(-1, DTMFRequest, null, null);
		
		qual = sdev.getQualifier();
		if ((qual.equals(passwd)) ||
		    (qual.equals(SignalDetector.q_NumSignals))) {
		    if (sdev.getSignalString().equals(password)) {
			playbackMessages(); // password OK
		    } else {
			play(errMsg, 0, null, null); // Play an error message
		    }
		} else if (qual.equals(stop)) {
		    recordNewMessage();
		} else if (qual.equals(oper)) {
		    releaseToService("operator", 5000); // release to "operator"
		    return;
		} else if (qual.equals(drop)) {
		    // User asked for drop, so we use JTAPI:
		    getTerminal().getTerminalConnections()[0].getConnection().disconnect();
		    break;
		}
	    }
	}
	catch (DisconnectedException ex) {} // Caller gone, nothing else to do.
	catch (Exception ex) {
	    // un-expected Exception
	    System.err.println(ex);
	    // Sorry. Call will be released...
	}
	release();
	return;
    }

    /**
     * play all the user's mailbox entries sequentially...
     */
    private void playbackMessages() throws Exception  {
	String[] message = {msgSeparator, msgSeparator};
	for (Enumeration e = mailBox.elements(); 
	     e.hasMoreElements();
	     message[1] = (String)e.nextElement())
	    while (true) {	// play this message, until user is done
		pev = play(message, 0, messageRTC, null);
		qual = pev.getQualifier();
		rtcc = pev.getRTCTrigger();
		// why did we complete?
		if (qual == pev.q_EndOfData) break; // do next message
		else if (qual == pev.q_RTC) {
		    // which RTC was it?
		    if (rtcc == replay) continue; // play again
		    else if (rtcc == stop) break; // next message
		    else if (rtcc == drop) return; // to main menu
		} 
	    }
	return;
    }
    
    /**
     *  Record a message and append it to the mailbox.
     */
    private void recordNewMessage() throws Exception {
	// create a new unique MSC identifier...
	String tvm = "mailBox/" + mailBox.size();
	
	RTC[] recordRTC = {RTC.SigDet_StopRecord};
	
	try {
	    rev = record(tvm, recordRTC, null);
	} catch (DisconnectedException ex) {
	    // disconnect is expected, just save message.
	}
	mailBox.addElement(tvm);
    }
}
